#!/usr/bin/env bash
set -eo pipefail
LAB_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
sudo apt-get update
sudo apt-get install -y "$LAB_DIR/deb/turtlebot3-controller_1.1.0_all.deb"
